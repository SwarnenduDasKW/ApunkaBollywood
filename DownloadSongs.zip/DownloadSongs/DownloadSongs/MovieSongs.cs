﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DownloadSongs
{
    class MovieSongs
    {
        public string MovieName { get; set; }
        public string SongTitle { get; set; }
        public string DownloadLink { get; set; }
        public string MP3Link { get; set; }
        public string Artist { get; set; }
    }
}
